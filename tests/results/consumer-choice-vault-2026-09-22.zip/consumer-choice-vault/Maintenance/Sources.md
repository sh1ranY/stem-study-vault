# 来源登记

来源范围：用户指定 sources 文件夹中的全部 3 份 Markdown，均为 version 1 的原创合成教学材料。原文明确说明不是官方大学讲义；权威类型记为**authored demonstration／原创教学演示材料**。未提供官方答案、考试文件、学期日程或讲义外的课程要求。

| 稳定 ID | 标题与原文副本 | 版本 | 角色 | 读取状态与限制 |
| --- | --- | --- | --- | --- |
| F01 | [[Sources/Original/L01 Preferences and ordinary demand]] | v1 | 预算、普通需求、边界案例与比较例题 | Slide 1–5 全部阅读；Slide 5 仅行政说明 |
| F02 | [[Sources/Original/L02 Compensated demand and price changes]] | v1 | 补偿需求、有限分解、几何与补偿差别 | Slide 1–6 全部阅读 |
| F03 | [[Sources/Original/L03 Elasticity and practice]] | v1 | 弹性与 P1–P3 练习 | Slide 1–5 全部阅读；没有官方解答 |

这些原文没有 PDF 页码、扫描图或 PPT 隐藏页。“Slide n”是每份 Markdown 的实际章节标题。本 vault 直接链接对应章节，不虚构物理页码。所有原文未改动复制到 `Sources/Original`；预算线和分解图由源材料的画图要求及例题数字重绘，不是原始讲义图片。

## 身份与完整性

以下 SHA-256 在写入前记录，完成后再次比较原输入与副本。完整机器记录在 `source-inventory.json`，检查细节见 [[Maintenance/Verification]]。

| 文件 | 字节数 | SHA-256 |
| --- | ---: | --- |
| L01 Preferences and ordinary demand.md | 1838 | `44845bcf8cd3e9a9fd73c8b4bdd08eb33278f1fd07e2d749c68a6647baf9131f` |
| L02 Compensated demand and price changes.md | 2298 | `8c56aa058dd3790a27d1f58326afb347248cc7b4a43772e43e8fca45fc1b0692` |
| L03 Elasticity and practice.md | 2032 | `7af01831bf26c41e5a4178ca561a7cad8133ad3a31aa9dfe6f965cda6e6a1a3a` |

没有未读来源区域、来源冲突或为缩短篇幅而排除的实质内容。源文件的身份陈述只支持合成课程范围，不能据此声称官方认证。编写者扩充了约束绑定的证明、推导理由、线性效用边界解释与 Slutsky 重新最优化的对照，正文已标记这些补充。
