# 内容义务与覆盖核对

本表按来源章节和实质内容逐项追踪，来源均为 [[Maintenance/Sources|登记的 v1]]。这里“已核对”表示已把原文要求与目标段落实质对照，**不表示学习者已掌握**。数学、图形与链接的独立检查另记于 [[Maintenance/Verification]]。

## 章节全量账目

F01 Slide 1–4 各自对应下列 F01 条目；Slide 5 为行政说明，未虚构课程时间表。F02 Slide 1–6 全部对应下列 F02 条目。F03 Slide 1–5 全部对应下列 F03 条目。共 16 个章节，15 个有教学或练习内容，1 个行政章节；没有未检查章节。

## F01：预算与普通需求

| 项目与实际来源定位 | 类型 | 必须保留的内容义务 | 先修与补足 | 实际教学位置 | 处置与证据 |
| --- | --- | --- | --- | --- | --- |
| F01-1a，[[Sources/Original/L01 Preferences and ordinary demand#Slide 1 — Quantities, prices and budget]] | 概念、条件 | 两种可分割非负数量，正价格正收入；效用排序而非幸福物理量；预算不等式 | 基本代数；正文定义符号 | [[Lessons/01 预算与普通需求#商品、偏好与可行集合]] | 已核对：定义、模型与解释均写出 |
| F01-1b，同 Slide 1 | 图形、推导 | 横纵截距与斜率的推导和经济解释；画预算线 | 直线方程；正文逐个令坐标为零 | [[Lessons/01 预算与普通需求#商品、偏好与可行集合]] | 已核对：含第一象限可行域、截距和比例解释及 SVG |
| F01-2a，[[Sources/Original/L01 Preferences and ordinary demand#Slide 2 — Interior optimum and ordinary demand]] | 条件 | 最优数量正、预算花完的理由 | 单调性；正文补边界比较 | [[Lessons/01 预算与普通需求#把限制代入目标：约束优化的第一步]] | 已核对：零效用边界与未花完可改善的证明 |
| F01-2b，同 Slide 2 | 推导 | 代入单变量函数；可行域；一阶、二阶导数；两种普通需求 | 基本导数；正文重启幂求导规则 | [[Lessons/01 预算与普通需求#把限制代入目标：约束优化的第一步]] | 已核对：每次非显然变形有理由，并检查唯一最大值 |
| F01-2c，同 Slide 2 | 结论、限制 | 平均支出份额为该偏好特性，不普遍化 | 两种需求公式 | [[Lessons/01 预算与普通需求#把限制代入目标：约束优化的第一步]] | 已核对：支出检查及适用范围明确 |
| F01-3a，[[Sources/Original/L01 Preferences and ordinary demand#Slide 3 — Tangency and its limit]] | 概念、推导 | 正效用曲线斜率、正 MRS 含义、内点相切 | 求导；正文补边际效用和沿预算线变化率 | [[Lessons/01 预算与普通需求#切线条件表示什么]] | 已核对：局部交换解释，区分负斜率与大小 |
| F01-3b，同 Slide 3 | 独立例题、条件 | $x+y,(2,1),M=16$ 的边界 $(0,16)$；为什么相切无解不等于优化无解 | 预算代入；无须额外先修 | [[Lessons/01 预算与普通需求#为什么切线不能解决所有题]] | 已核对：每元效用与单调函数两种理由，另配图 |
| F01-4a，[[Sources/Original/L01 Preferences and ordinary demand#Slide 4 — Worked example]] | 例题 | $xy,M=40,(2,1)$ 的数量、支出份额、效用、两截距 | F01-1、F01-2 | [[Lessons/01 预算与普通需求#展开例题：价格与收入的三个状态]] | 已核对：原数值全部保留；问题分项见 Questions |
| F01-4b，同 Slide 4 | 例题、比较 | 两价格翻倍但收入不变的数量、预算与效用影响 | 原例及预算线 | [[Lessons/01 预算与普通需求#展开例题：价格与收入的三个状态]] | 已核对：独立状态和表行，没有与同比例收入混合 |
| F01-4c，同 Slide 4 | 例题、比较 | 两价格与收入都翻倍的另一种结果 | 等式同除一个正数 | [[Lessons/01 预算与普通需求#展开例题：价格与收入的三个状态]] | 已核对：约束集合相同的理由和数值结果 |
| F01-5，[[Sources/Original/L01 Preferences and ordinary demand#Slide 5 — Administration]] | 行政 | 合成阅读安排；无日期或考试主张 | 无 | [[Course]]、[[Maintenance/Sources]] | 非教学排除：只保留范围声明，不创建虚构周次 |

## F02：补偿需求与价格变化

| 项目与实际来源定位 | 类型 | 必须保留的内容义务 | 先修与补足 | 实际教学位置 | 处置与证据 |
| --- | --- | --- | --- | --- | --- |
| F02-1a，[[Sources/Original/L02 Compensated demand and price changes#Slide 1 — A different optimization question]] | 对比概念 | 普通固定收入最大化效用，Hicks 固定正效用最小化支出；输入与结果 | 第一课普通模型 | [[Lessons/02 补偿需求#两个优化问题，固定条件不同]] | 已核对：正文解释、正式模型与输入输出表 |
| F02-1b，同 Slide 1 | 条件、证明 | 目标取等号，两数量为正 | 正目标；正文补缩放证明 | [[Lessons/02 补偿需求#两个优化问题，固定条件不同]] | 已核对：不是只直接宣告等号 |
| F02-2a，[[Sources/Original/L02 Compensated demand and price changes#Slide 2 — Derivation]] | 推导、条件 | $E(x)$，正定义域，求导，正根，二阶与最低点检查 | 第一课代入；正文复习 $x^{-1}$ 导数 | [[Lessons/02 补偿需求#沿目标曲线最小化支出]] | 已核对：严格凸与两端发散解释 |
| F02-2b，同 Slide 2 | 推导 | 两种 $h$、$e$，乘积与支出检查 | F02-2a | [[Lessons/02 补偿需求#沿目标曲线最小化支出]] | 已核对：从 $h_x$ 到 $h_y$ 和支出，未略去第二种数量 |
| F02-2c，同 Slide 2 | 几何、推导 | $h_y/h_x=p_x/p_y$ 的相切解释，不能仅代数相除 | 第一课 MRS，在正文再次激活 | [[Lessons/02 补偿需求#再看相切：比例和效用各管什么]] | 已核对：平移等支出线与斜率不等可节省的理由 |
| F02-3a，[[Sources/Original/L02 Compensated demand and price changes#Slide 3 — Finite Hicks decomposition, worked example]] | 完整例题 | $M=32,(1,1)\to(4,1)$；A、B、C 的两坐标、效用、各状态支出及实验定义 | 普通与 Hicks 推导 | [[Lessons/03 价格变化的分解#先定义三个实验，再代入数字]] | 已核对：联立两条件说明 B；全三状态表 |
| F02-3b，同 Slide 3 | 例题、解释 | 两种 $x$ 效应、相加检查、B 超实际收入与名义不变的解释 | 三个状态 | [[Lessons/03 价格变化的分解#两段变化如何相加]] | 已核对：分别固定效用／价格，恒等式与经济解释分开 |
| F02-4a，[[Sources/Original/L02 Compensated demand and price changes#Slide 4 — Geometry]] | 图形、方程 | 三条预算线，旧效用相切，横纵轴与 A、B、C 一致 | 截距、斜率、目标曲线 | [[Lessons/03 价格变化的分解#图上同时追踪效用与价格比]] | 已核对：SVG、三条方程、截距和切线斜率 |
| F02-4b，同 Slide 4 | 图形解释 | A、B 同效用；B、C 同价格比；改标签仍能辨别效应 | 三实验定义 | [[Lessons/03 价格变化的分解#图上同时追踪效用与价格比]] | 已核对：从条件识别，不靠字母记忆 |
| F02-5，[[Sources/Original/L02 Compensated demand and price changes#Slide 5 — A distinct compensation]] | 独立比较、条件 | 旧组合新价格成本与旧效用最低支出；两种额外补偿；有限 Slutsky 与 Hicks 区别 | F02-3 | [[Lessons/03 价格变化的分解#能买回旧组合，不等于最低成本恢复旧效用]] | 已核对：总收入 $80/64$ 与额外 $48/32$；重新最优为作者补充；不要求微分方程 |
| F02-6，[[Sources/Original/L02 Compensated demand and price changes#Slide 6 — Direction and assumptions]] | 条件、解释 | 两种普通需求收入导数为正；正常品；不普遍推广收入效应方向 | 简单偏导；正文重申固定价格 | [[Lessons/03 价格变化的分解#为什么本例两段都是负的]] | 已核对：两商品均证明，与例中负效应关联，保留劣等品限制 |

## F03：弹性与全部练习

| 项目与实际来源定位 | 类型 | 必须保留的内容义务 | 先修与补足 | 实际教学位置 | 处置与证据 |
| --- | --- | --- | --- | --- | --- |
| F03-1a，[[Sources/Original/L03 Elasticity and practice#Slide 1 — Point elasticity]] | 概念、约定 | 带符号自身价格点弹性；斜率变无量纲比例反应 | 基本导数；正文解释固定变量与单位 | [[Lessons/04 弹性与有限变化#从斜率到无量纲的局部反应]] | 已核对：定义、局部相对变化式、正值条件 |
| F03-1b，同 Slide 1 | 推导 | 普通弹性 $-1$，固定收入与另一价格 | 普通需求 | [[Lessons/04 弹性与有限变化#普通需求：固定收入和另一价格]] | 已核对：偏导与弹性代入步骤 |
| F03-1c，同 Slide 1 | 推导、比较 | 补偿弹性 $-1/2$，固定目标效用与另一价格 | 补偿需求，幂导数在正文展开 | [[Lessons/04 弹性与有限变化#补偿需求：固定目标效用和另一价格]] | 已核对：不是套普通弹性，解释支出可变 |
| F03-2a，[[Sources/Original/L03 Elasticity and practice#Slide 2 — Finite price change]] | 例子、条件 | 翻倍价格两种精确倍数；局部点弹性不能任意乘有限百分比 | 两种函数，百分比在正文说明 | [[Lessons/04 弹性与有限变化#大幅变价时回到需求函数]] | 已核对：新旧比与减一分开，无弧弹性扩展 |
| F03-2b，同 Slide 2 | 符号约定 | 带符号与绝对值两种惯例 | 弹性定义 | [[Lessons/04 弹性与有限变化#补偿需求：固定目标效用和另一价格]] | 已核对：明确负方向与幅度数值 |
| F03-3，[[Sources/Original/L03 Elasticity and practice#Slide 3 — P1: Budget and a boundary case]] | 练习 | P1(a) 数量、支出；(b) MRS；(c) 改线性效用与方法理由 | 第一课全部 | [[Practice/P1 预算与边界#题目]] | 已核对：3 子问均有题干、分离提示与作者解答 |
| F03-4，[[Sources/Original/L03 Elasticity and practice#Slide 4 — P2: A full decomposition]] | 练习 | P2(a) A/B/C；(b) 两效果及总和；(c) 两补偿；(d) 三线、斜率、截距 | 第一至三课 | [[Practice/P2 完整价格分解#题目]] | 已核对：4 子问齐全，含常被漏掉的 (c)(d) |
| F03-5，[[Sources/Original/L03 Elasticity and practice#Slide 5 — P3: Elasticity and a large change]] | 练习 | P3(a) 两弹性与固定量；(b) 三倍价的精确比例；(c) 实验差异解释 | 第四课 | [[Practice/P3 弹性与大幅变价#题目]] | 已核对：3 子问齐全，未把收入和效用同时固定 |

所有例题和练习的稳定编号、答案身份见 [[Maintenance/Questions]]。本次不存在必须保留但尚未教学的来源条目；没有把难点改列为选读或源链接来代替教学。
